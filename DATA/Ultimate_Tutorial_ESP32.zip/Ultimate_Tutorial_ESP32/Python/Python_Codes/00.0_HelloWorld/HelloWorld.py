
print('Hello World!\n')