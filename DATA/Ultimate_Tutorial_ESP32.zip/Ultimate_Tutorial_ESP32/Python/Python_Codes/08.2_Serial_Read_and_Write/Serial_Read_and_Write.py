print(str("\nESP32 initialization completed!\n")
      + str("Please input some characters,\n")
      + str("select \"Newline\" below and click send button. \n"))
while True:
    print("inputString: ",input())